package vue;

public class PanelStats extends PanelPrincipal{
	public PanelStats() {
		super();
	}
}
