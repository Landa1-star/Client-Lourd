package vue;

public class PanelPlannings extends PanelPrincipal{
	public PanelPlannings() {
		super();
	}
}
